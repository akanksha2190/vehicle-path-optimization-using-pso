package algoProject;

public class VisitingStations {
	private int stationX = 0;
	private int stationY = 0;

	public int x()
	{
	    return stationX;
	}
	
	public void x(final int xCoordinate)
	{
	    stationX = xCoordinate;
	    return;
	}

	public int y()
	{
	    return stationY;
	}
	
	public void y(final int yCoordinate)
	{
	    stationY = yCoordinate;
	    return;
	}

}
